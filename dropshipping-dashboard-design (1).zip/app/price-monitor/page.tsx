"use client"
import { useState } from "react"
import { HelpCircle, User, RefreshCw, Download, Plus, Zap } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import Link from "next/link"

export default function PriceMonitor() {
  const [isProfitModalOpen, setIsProfitModalOpen] = useState(false)
  const [isSmartPricingOpen, setIsSmartPricingOpen] = useState(false)
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false)
  const [isExportModalOpen, setIsExportModalOpen] = useState(false)
  const [isSyncing, setIsSyncing] = useState(false)
  const [isAutoFulfillEnabled, setIsAutoFulfillEnabled] = useState(true)
  const [exportProgress, setExportProgress] = useState(0)

  const [profitData, setProfitData] = useState({ cost: 0, sale: 0, profit: 0, roi: 0 })
  const [stockThreshold, setStockThreshold] = useState(5)

  const calculateProfit = (cost: number, sale: number) => {
    const profit = sale - cost
    const roi = cost > 0 ? (profit / cost) * 100 : 0
    setProfitData({ cost, sale, profit, roi })
  }

  const runSync = () => {
    setIsSyncing(true)
    setTimeout(() => setIsSyncing(false), 3000)
  }

  const startExport = () => {
    setIsExportModalOpen(true)
    setExportProgress(0)
    const interval = setInterval(() => {
      setExportProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            alert("Export complete")
            setIsExportModalOpen(false)
            setExportProgress(0)
          }, 500)
          return 100
        }
        return prev + Math.random() * 30
      })
    }, 400)
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-gray-900">Price Monitor</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <HelpCircle className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <User className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-8 space-y-8">
            {/* Title */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Price Monitor</h2>
              <p className="text-gray-600 mt-2">Manage pricing, orders, alerts, and automation rules</p>
            </div>

            {/* Interactive Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div
                onClick={runSync}
                className="group cursor-pointer p-6 bg-white rounded-xl border-2 border-transparent shadow-sm transition-all duration-300 hover:border-blue-500 hover:shadow-md active:scale-95"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
                    <RefreshCw
                      className={`w-6 h-6 text-blue-600 transition-transform duration-500 ${isSyncing ? "animate-spin" : "group-hover:rotate-180"}`}
                    />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-green-500 bg-green-50 px-2 py-1 rounded-full">
                    Live
                  </span>
                </div>
                <h3 className="font-bold text-gray-800 group-hover:text-blue-600 transition-colors">Order Sync</h3>
                <p className="text-sm text-gray-500 mt-1">Sync orders from all suppliers</p>
                <div className="mt-4 pt-4 border-t border-gray-50 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-xs text-blue-500 font-medium">Click to sync now →</span>
                </div>
              </div>

              <div
                onClick={() => setIsProfitModalOpen(true)}
                className="group cursor-pointer p-6 bg-white rounded-xl border border-gray-100 shadow-sm transition-all hover:shadow-lg active:scale-95"
              >
                <div className="p-3 w-fit bg-blue-50 rounded-lg text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-gray-800 mt-4">Profit Calculator</h3>
                <p className="text-xs text-gray-500 mt-1">Simulate margins and fees</p>
              </div>

              <div className="group cursor-pointer p-6 bg-white rounded-xl border border-gray-100 shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl active:scale-95">
                <div className="flex justify-between items-center mb-4">
                  <div className="p-3 bg-green-50 rounded-lg text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all duration-300">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                      />
                    </svg>
                  </div>
                </div>
                <h3 className="font-bold text-gray-800">Sales Analytics</h3>
                <p className="text-xs text-gray-500 mt-2 text-balance">
                  View detailed sales reports and revenue trends
                </p>
                <div className="mt-4 flex items-end gap-1 h-8">
                  <div className="w-full bg-green-100 h-4 rounded-t group-hover:h-6 transition-all duration-500" />
                  <div className="w-full bg-green-200 h-6 rounded-t group-hover:h-4 transition-all duration-500" />
                  <div className="w-full bg-green-100 h-3 rounded-t group-hover:h-8 transition-all duration-500" />
                  <div className="w-full bg-green-300 h-7 rounded-t group-hover:h-5 transition-all duration-500" />
                </div>
              </div>

              <div
                onClick={() => setIsAlertsModalOpen(true)}
                className="group cursor-pointer p-6 bg-white rounded-xl border border-gray-100 shadow-sm transition-all hover:shadow-lg relative overflow-hidden"
              >
                <div className="p-3 w-fit bg-red-50 rounded-lg text-red-600 group-hover:bg-red-600 group-hover:text-white transition-all duration-300">
                  <svg
                    className="w-6 h-6 group-hover:animate-bounce"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-gray-800 mt-4">Stock Alerts</h3>
                <p className="text-xs text-gray-500 mt-1">Configure stock level notifications</p>
              </div>

              <div className="relative group p-6 bg-white rounded-xl border border-gray-100 shadow-sm transition-all hover:shadow-lg">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 bg-purple-50 rounded-lg text-purple-600 group-hover:bg-purple-100 transition-colors">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                      />
                      <circle cx="12" cy="12" r="3" />
                    </svg>
                  </div>
                  <label className="inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={isAutoFulfillEnabled}
                      onChange={() => setIsAutoFulfillEnabled(!isAutoFulfillEnabled)}
                    />
                    <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600" />
                  </label>
                </div>
                <h3 className="font-bold text-gray-800 cursor-pointer" onClick={() => setIsSmartPricingOpen(true)}>
                  Smart Pricing Rules
                </h3>
                <p className="text-xs text-gray-500 mt-2">Auto-adjust prices based on your profit rules</p>
              </div>

              <div
                onClick={startExport}
                className="group cursor-pointer p-6 bg-white rounded-xl border border-gray-100 shadow-sm transition-all hover:shadow-lg active:scale-95"
              >
                <div className="p-3 w-fit bg-orange-50 rounded-lg text-orange-600 group-hover:bg-orange-600 group-hover:text-white transition-all">
                  <Download className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-800 mt-4">Export Orders</h3>
                <p className="text-xs text-gray-500 mt-1">Download CSV/Excel reports</p>
              </div>
            </div>

            {/* Action Bar */}
            <div className="relative mt-6 w-full">
              <div className="bg-white/90 backdrop-blur-lg border border-gray-200 shadow-2xl rounded-2xl p-3 flex items-center justify-between gap-3">
                <button
                  onClick={runSync}
                  disabled={isSyncing}
                  className="relative flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-xl font-bold transition-all active:scale-95 shadow-lg group disabled:opacity-80 disabled:cursor-not-allowed"
                >
                  <RefreshCw
                    className={`w-5 h-5 transition-transform duration-500 ${isSyncing ? "animate-spin" : "group-hover:rotate-180"}`}
                  />
                  <span className="hidden md:inline">{isSyncing ? "Syncing..." : "Sync Orders"}</span>
                </button>

                <Link href="/tools" className="flex-1">
                  <button className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-xl font-bold transition-all active:scale-95 shadow-lg">
                    <Zap className="w-5 h-5" />
                    <span className="hidden md:inline">Auto Fulfill Settings</span>
                  </button>
                </Link>

                <button
                  onClick={startExport}
                  className="flex-1 flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white py-3 px-4 rounded-xl font-bold transition-all active:scale-95 shadow-lg"
                >
                  <Download className="w-5 h-5" />
                  <span className="hidden md:inline">Export Data</span>
                </button>

                <Link href="/products">
                  <button className="h-12 w-12 flex items-center justify-center bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-bold transition-all active:scale-110 hover:rotate-90 shadow-lg">
                    <Plus className="w-6 h-6" />
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {isProfitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all">
            <div className="p-6 border-b flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-lg text-gray-800">Quick Profit Calc</h3>
              <button
                onClick={() => setIsProfitModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                &times;
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Cost Price ($)</label>
                <input
                  type="number"
                  placeholder="0.00"
                  onChange={(e) => calculateProfit(Number(e.target.value), profitData.sale)}
                  className="w-full p-3 bg-gray-50 border rounded-lg outline-none focus:border-blue-500 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Selling Price ($)</label>
                <input
                  type="number"
                  placeholder="0.00"
                  onChange={(e) => calculateProfit(profitData.cost, Number(e.target.value))}
                  className="w-full p-3 bg-gray-50 border rounded-lg outline-none focus:border-blue-500 transition-all"
                />
              </div>
              <div className="mt-6 p-4 bg-blue-600 rounded-xl text-white">
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-80">Estimated Profit:</span>
                  <span className="text-2xl font-bold">${profitData.profit.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center mt-2 pt-2 border-t border-white/20">
                  <span className="text-sm opacity-80">ROI:</span>
                  <span className="font-bold">{profitData.roi.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {isSmartPricingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all scale-100">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-xl font-bold text-gray-800">Smart Pricing Configuration</h3>
              <button onClick={() => setIsSmartPricingOpen(false)} className="text-gray-400 hover:text-gray-600">
                ✕
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Profit Margin (%)</label>
                <input
                  type="number"
                  placeholder="20"
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
              <div className="bg-blue-50 p-4 rounded-lg flex items-start gap-3">
                <div className="text-blue-500 mt-1">💡</div>
                <p className="text-sm text-blue-700">
                  The system will automatically recalculate your store price every time the supplier changes their
                  price.
                </p>
              </div>
            </div>
            <div className="p-6 border-t flex justify-end gap-3">
              <button
                onClick={() => setIsSmartPricingOpen(false)}
                className="px-6 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => setIsSmartPricingOpen(false)}
                className="px-6 py-2 bg-purple-600 text-white font-bold rounded-lg hover:bg-purple-700 shadow-lg transition-transform active:scale-95"
              >
                Save Rule
              </button>
            </div>
          </div>
        </div>
      )}

      {isAlertsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Stock Alerts</h3>
              <button
                onClick={() => setIsAlertsModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                &times;
              </button>
            </div>
            <div className="space-y-4">
              <p className="text-sm text-gray-600">Set the minimum stock level before receiving alerts</p>
              <input
                type="range"
                min="0"
                max="50"
                value={stockThreshold}
                onChange={(e) => setStockThreshold(Number(e.target.value))}
                className="w-full h-2 bg-red-100 rounded-lg appearance-none cursor-pointer accent-red-600"
              />
              <p className="mt-2 text-center font-bold text-red-600">
                Notify me when stock is below: <span>{stockThreshold}</span> units
              </p>
            </div>
            <div className="mt-6 pt-6 border-t">
              <button
                onClick={() => setIsAlertsModalOpen(false)}
                className="w-full px-6 py-3 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700"
              >
                Save Alert Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-8 text-center">
            <div className="mb-4 text-orange-500 flex justify-center">
              <svg className="w-12 h-12 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0l-4 4m4-4v12"
                />
              </svg>
            </div>
            <h3 className="text-lg font-bold text-gray-800">Preparing your file...</h3>
            <p className="text-sm text-gray-500 mt-2">We are gathering all your order data.</p>
            <div className="w-full bg-gray-100 h-2 rounded-full mt-6 overflow-hidden">
              <div
                className="bg-orange-500 h-full transition-all duration-300"
                style={{ width: `${exportProgress}%` }}
              />
            </div>
            <p className="text-[10px] text-gray-400 mt-2 uppercase font-bold tracking-widest">
              {Math.floor(exportProgress)}% Complete
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
