"use client"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Sidebar } from "@/components/sidebar"

export default function TermsOfService() {
  return (
    <div className="flex h-screen bg-white">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-gray-900">Terms of Service</h1>
          <Link href="/dashboard" className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto p-8 space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Terms of Service</h2>
              <p className="text-sm text-gray-500 mt-2">Last Updated: January 2026</p>
            </div>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">1. Introduction</h3>
              <p className="text-gray-600 leading-relaxed">Welcome to our platform. By using our services, you agree to comply with these Terms of Service.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">2. Use of Service</h3>
              <p className="text-gray-600 leading-relaxed">You agree to use our services only for lawful purposes and in accordance with these Terms.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">3. Account Responsibility</h3>
              <p className="text-gray-600 leading-relaxed">Users are responsible for maintaining the confidentiality of their account credentials and for all activities that occur under their account.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">4. Content</h3>
              <p className="text-gray-600 leading-relaxed">All content uploaded by users remains their property. By uploading, you grant us a license to use the content to operate and improve the service.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">5. Termination</h3>
              <p className="text-gray-600 leading-relaxed">We reserve the right to suspend or terminate accounts that violate these Terms.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">6. Limitation of Liability</h3>
              <p className="text-gray-600 leading-relaxed">We are not liable for any indirect, incidental, or consequential damages arising from the use of our services.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">7. Changes to Terms</h3>
              <p className="text-gray-600 leading-relaxed">We may update these Terms at any time. Continued use of the service constitutes acceptance of the updated Terms.</p>
            </section>

            <section className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-800">8. Contact</h3>
              <p className="text-gray-600 leading-relaxed">For questions about these Terms, contact: support@yourdomain.com</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}
