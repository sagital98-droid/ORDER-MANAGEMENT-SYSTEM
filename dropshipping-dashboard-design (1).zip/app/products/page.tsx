"use client"

import { useState } from "react"
import { Search, Plus, Filter, Grid, List, Package } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import Link from "next/link"
import { ImportProductsDropdown } from "@/components/import-products-dropdown"

export default function Products() {
  const [viewMode, setViewMode] = useState("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [products] = useState<any[]>([])

  const filteredProducts = products.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold text-foreground">Products</h1>
            <div className="flex items-center gap-3">
              <ImportProductsDropdown />
              <Link href="/products/new">
                <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition">
                  <Plus className="w-4 h-4" />
                  Add Product
                </button>
              </Link>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-1 flex items-center gap-2 bg-secondary rounded-lg px-3 py-2">
              <Search className="w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-foreground placeholder-muted-foreground outline-none"
              />
            </div>
            <button className="px-4 py-2 border border-border rounded-lg text-foreground hover:bg-muted transition flex items-center gap-2">
              <Filter className="w-4 h-4" />
              Filter
            </button>
            <div className="flex gap-1 bg-secondary rounded-lg p-1">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded transition ${viewMode === "grid" ? "bg-background" : "hover:bg-muted"}`}
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded transition ${viewMode === "list" ? "bg-background" : "hover:bg-muted"}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Products Grid/List */}
        <div className="flex-1 overflow-auto p-6">
          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <Package className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No products yet</h3>
              <p className="text-gray-500 mb-6 max-w-md">
                Get started by importing products from suppliers or adding them manually.
              </p>
              <div className="flex gap-3">
                <ImportProductsDropdown />
                <Link href="/products/new">
                  <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition">
                    <Plus className="w-4 h-4" />
                    Add Product Manually
                  </button>
                </Link>
              </div>
            </div>
          ) : viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredProducts.map((product) => (
                <Link key={product.id} href={`/products/${product.id}`}>
                  <div className="bg-white border border-border rounded-lg overflow-hidden hover:shadow-lg transition cursor-pointer h-full">
                    {/* Grid view products */}
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="bg-white border border-border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-secondary">
                    <th className="text-left px-6 py-3 font-semibold text-foreground">Product</th>
                    <th className="text-left px-6 py-3 font-semibold text-foreground">Supplier</th>
                    <th className="text-right px-6 py-3 font-semibold text-foreground">Price</th>
                    <th className="text-right px-6 py-3 font-semibold text-foreground">Cost</th>
                    <th className="text-right px-6 py-3 font-semibold text-foreground">Profit</th>
                    <th className="text-center px-6 py-3 font-semibold text-foreground">Rating</th>
                    <th className="text-center px-6 py-3 font-semibold text-foreground">Stock</th>
                    <th className="text-center px-6 py-3 font-semibold text-foreground"></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product) => (
                    <tr key={product.id} className="border-b border-border hover:bg-secondary transition">
                      <td className="px-6 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            className="w-10 h-10 rounded object-cover"
                          />
                          <div>
                            <p className="font-medium text-foreground">{product.name}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-3 text-foreground">{product.supplier}</td>
                      <td className="px-6 py-3 text-right font-semibold text-foreground">${product.price}</td>
                      <td className="px-6 py-3 text-right text-foreground">${product.cost}</td>
                      <td className="px-6 py-3 text-right font-semibold text-green-600">${product.profit}</td>
                      <td className="px-6 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <span className="text-yellow-400">★</span>
                          <span className="font-semibold text-foreground">{product.rating}</span>
                        </div>
                      </td>
                      <td className="px-6 py-3 text-center">
                        <span
                          className={`inline-block px-2 py-1 rounded text-xs font-semibold ${
                            product.stock > 100 ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"
                          }`}
                        >
                          {product.stock}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-center">
                        <button className="p-1 hover:bg-muted rounded transition">
                          <Plus className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
