"use client"

import { useState } from "react"
import {
  ChevronLeft,
  ChevronRight,
  Upload,
  Trash2,
  Zap,
  Star,
  Copy,
  Eye,
  MoreVertical,
  MessageSquare,
} from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import Link from "next/link"

export default function ProductDetails() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showImageUpload, setShowImageUpload] = useState(false)
  const [selectedVariation, setSelectedVariation] = useState("")
  const [profitCalculatorOpen, setProfitCalculatorOpen] = useState(false)
  const [images, setImages] = useState<string[]>([])

  const handlePrevImage = () => {
    if (images.length === 0) return
    setCurrentImageIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1))
  }

  const handleNextImage = () => {
    if (images.length === 0) return
    setCurrentImageIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1))
  }

  const handleDeleteImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
    if (currentImageIndex >= images.length - 1 && currentImageIndex > 0) {
      setCurrentImageIndex(currentImageIndex - 1)
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />

      <div className="flex-1 overflow-auto">
        <div className="bg-white border-b border-border p-6">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">Product Title</h1>
              <div className="flex gap-2">
                <span className="inline-block bg-gray-100 text-gray-700 text-xs font-semibold px-3 py-1 rounded-full">
                  No Tags
                </span>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition">
                <Zap className="w-4 h-4" />
                AI Suggestion
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/90 transition">
                Edit
              </button>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-3 gap-6">
            <div className="col-span-2 space-y-4">
              <div className="bg-white border border-border rounded-lg overflow-hidden">
                <div className="bg-gray-100 relative h-96 flex items-center justify-center group">
                  {images.length === 0 ? (
                    <div className="text-center">
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">No images uploaded</p>
                      <p className="text-sm text-gray-400 mt-1">Click below to add product images</p>
                    </div>
                  ) : (
                    <>
                      <img
                        src={images[currentImageIndex] || "/placeholder.svg"}
                        alt="Product"
                        className="w-full h-full object-cover"
                      />

                      <button
                        onClick={handlePrevImage}
                        className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button
                        onClick={handleNextImage}
                        className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>

                      <div className="absolute bottom-3 right-3 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        {currentImageIndex + 1} / {images.length}
                      </div>
                    </>
                  )}
                </div>

                <div className="flex gap-2 p-4 bg-gray-50 overflow-x-auto">
                  {images.map((img, index) => (
                    <div
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`relative flex-shrink-0 cursor-pointer rounded overflow-hidden border-2 transition ${
                        index === currentImageIndex ? "border-blue-500" : "border-gray-300"
                      }`}
                    >
                      <img src={img || "/placeholder.svg"} alt={`Thumb ${index}`} className="w-16 h-16 object-cover" />
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDeleteImage(index)
                        }}
                        className="absolute top-0 right-0 bg-red-500 text-white p-1 opacity-0 hover:opacity-100 transition"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => setShowImageUpload(!showImageUpload)}
                    className="flex-shrink-0 w-16 h-16 border-2 border-dashed border-gray-300 rounded flex items-center justify-center bg-gray-50 hover:bg-gray-100 transition cursor-pointer"
                  >
                    <Upload className="w-5 h-5 text-gray-400" />
                  </button>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-700">
                Upload product images | Auto-optimized for web
              </div>
            </div>

            {/* Product Info Panel - Right */}
            <div className="bg-white border border-border rounded-lg p-6 space-y-4 h-fit">
              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">Variations</label>
                <select
                  value={selectedVariation}
                  onChange={(e) => setSelectedVariation(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground"
                >
                  <option value="">Select variation</option>
                  <option value="size">Size</option>
                  <option value="color">Color</option>
                  <option value="material">Material</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">Status</label>
                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg">
                  <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                  <span className="text-sm text-gray-600 font-medium">Not Set</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">Description</label>
                <textarea
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm resize-none h-20"
                  placeholder=""
                  defaultValue=""
                />
                <button className="w-full mt-2 flex items-center justify-center gap-2 px-3 py-2 bg-purple-50 text-purple-600 hover:bg-purple-100 rounded-lg text-sm font-medium transition">
                  <Zap className="w-3 h-3" />
                  Enhance with AI
                </button>
              </div>

              <div className="space-y-2">
                <button className="w-full px-3 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/90 font-medium transition">
                  Save Draft
                </button>
                <Link href="/stores">
                  <button className="w-full px-3 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 font-medium transition">
                    Import to Shop
                  </button>
                </Link>
                <button className="w-full px-3 py-2 border border-border text-foreground rounded-lg hover:bg-muted transition font-medium">
                  Preview
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Three Sections */}
          <div className="grid grid-cols-3 gap-6">
            {/* Supplier & Shipping */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Supplier & Shipping</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-1">Supplier</label>
                  <p className="text-sm font-medium text-foreground">No supplier connected</p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-1">Shipping Time</label>
                  <p className="text-sm text-foreground">Not configured</p>
                </div>
                <Link href="/stores">
                  <button className="w-full mt-4 px-4 py-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg text-sm font-medium transition">
                    Connect Supplier
                  </button>
                </Link>
              </div>
            </div>

            {/* Pricing & Profit */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Pricing & Profit</h3>
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Original Price:</span>
                  <span className="font-medium text-foreground">$0.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Current Price:</span>
                  <span className="font-medium text-foreground">$0.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Cost:</span>
                  <span className="font-medium text-foreground">$0.00</span>
                </div>
                <div className="border-t border-border pt-2 flex justify-between">
                  <span className="font-semibold text-foreground">Profit:</span>
                  <span className="font-bold text-gray-400">$0.00</span>
                </div>
              </div>
              <Link href="/price-monitor">
                <button className="w-full px-4 py-2 bg-green-50 text-green-600 hover:bg-green-100 rounded-lg text-sm font-medium transition">
                  Configure Pricing
                </button>
              </Link>
            </div>

            {/* Tags & Reviews */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Tags & Reviews</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-2">AI Tags</label>
                  <div className="flex flex-wrap gap-2">
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">No tags yet</span>
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-2">Rating</label>
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-gray-300" />
                    ))}
                    <span className="text-sm font-semibold text-foreground ml-1">No reviews</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Management & Monitoring Section */}
          <div className="bg-white border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Management & Monitoring</h3>
            <div className="grid grid-cols-4 gap-4">
              <div className="border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground text-sm mb-3">Price Monitoring</h4>
                <div className="text-xs text-muted-foreground mb-3">
                  <p className="mb-1">Current: $0.00</p>
                  <p className="mb-1">Supplier: $0.00</p>
                  <p className="text-gray-400 font-medium">No change</p>
                </div>
                <Link href="/price-monitor">
                  <button className="w-full px-3 py-1 text-xs bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition">
                    Configure
                  </button>
                </Link>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground text-sm mb-3">Change Log</h4>
                <div className="text-xs text-muted-foreground space-y-1 mb-3">
                  <p>No changes recorded</p>
                </div>
                <button className="w-full px-3 py-1 text-xs bg-gray-100 text-foreground rounded hover:bg-gray-200 transition">
                  View Full
                </button>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground text-sm mb-3 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Comments
                </h4>
                <p className="text-xs text-muted-foreground mb-3">0 internal notes</p>
                <button className="w-full px-3 py-1 text-xs bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition">
                  Add Note
                </button>
              </div>

              <div className="border border-border rounded-lg p-4 space-y-2">
                <button className="w-full px-3 py-1 text-xs bg-gray-100 text-foreground rounded hover:bg-gray-200 transition flex items-center justify-center gap-2">
                  <Copy className="w-3 h-3" />
                  Duplicate
                </button>
                <button className="w-full px-3 py-1 text-xs bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition flex items-center justify-center gap-2">
                  <Eye className="w-3 h-3" />
                  Compare
                </button>
                <button className="w-full px-3 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded transition">
                  <MoreVertical className="w-3 h-3 mx-auto" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
