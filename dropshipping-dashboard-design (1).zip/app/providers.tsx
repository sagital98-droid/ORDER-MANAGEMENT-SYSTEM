"use client"

import type React from "react"
import { useState, createContext, useContext } from "react"

interface AppContextType {
  isPrivacyPolicyOpen: boolean
  setIsPrivacyPolicyOpen: (value: boolean) => void
}

const AppContext = createContext<AppContextType>({
  isPrivacyPolicyOpen: false,
  setIsPrivacyPolicyOpen: () => {},
})

export const useAppContext = () => useContext(AppContext)

export function AppProviders({ children }: { children: React.ReactNode }) {
  const [isPrivacyPolicyOpen, setIsPrivacyPolicyOpen] = useState(false)

  return (
    <AppContext.Provider value={{ isPrivacyPolicyOpen, setIsPrivacyPolicyOpen }}>
      {children}
    </AppContext.Provider>
  )
}
