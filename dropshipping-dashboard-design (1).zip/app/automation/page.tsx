"use client"

import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Zap, Clock, Package, ShoppingCart, Bell, Settings, Play, Plus } from "lucide-react"
import { useState, Suspense } from "react"

function AutomationContent() {
  const [automations, setAutomations] = useState<any[]>([])

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Header />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Automation</h1>
              <p className="text-gray-500 text-sm mt-1">Automate your dropshipping workflow</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Plus className="w-4 h-4" />
              Create Rule
            </button>
          </div>

          {/* Automation Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-white p-4 rounded-xl border hover:shadow-md transition-shadow cursor-pointer">
              <div className="p-3 bg-blue-50 rounded-lg w-fit mb-3">
                <Package className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-800">Inventory Sync</h3>
              <p className="text-xs text-gray-500 mt-1">Auto-sync stock levels</p>
            </div>
            <div className="bg-white p-4 rounded-xl border hover:shadow-md transition-shadow cursor-pointer">
              <div className="p-3 bg-green-50 rounded-lg w-fit mb-3">
                <ShoppingCart className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-800">Order Processing</h3>
              <p className="text-xs text-gray-500 mt-1">Auto-fulfill orders</p>
            </div>
            <div className="bg-white p-4 rounded-xl border hover:shadow-md transition-shadow cursor-pointer">
              <div className="p-3 bg-orange-50 rounded-lg w-fit mb-3">
                <Bell className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="font-semibold text-gray-800">Price Alerts</h3>
              <p className="text-xs text-gray-500 mt-1">Notify on price changes</p>
            </div>
            <div className="bg-white p-4 rounded-xl border hover:shadow-md transition-shadow cursor-pointer">
              <div className="p-3 bg-purple-50 rounded-lg w-fit mb-3">
                <Clock className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-800">Scheduled Tasks</h3>
              <p className="text-xs text-gray-500 mt-1">Run tasks on schedule</p>
            </div>
          </div>

          {/* Active Automations */}
          <div className="bg-white rounded-xl border">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="font-semibold text-gray-800">Active Automations</h2>
              <button className="text-sm text-blue-600 hover:text-blue-700">View All</button>
            </div>

            {automations.length === 0 ? (
              <div className="p-12 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">No automations yet</h3>
                <p className="text-gray-500 text-sm mb-4">
                  Create your first automation rule to streamline your workflow
                </p>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Create First Automation
                </button>
              </div>
            ) : (
              <div className="divide-y">
                {automations.map((automation, index) => (
                  <div key={index} className="p-4 flex items-center justify-between hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-50 rounded-lg">
                        <Zap className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800">{automation.name}</h4>
                        <p className="text-xs text-gray-500">{automation.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="p-2 text-gray-400 hover:text-gray-600">
                        <Settings className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-green-600">
                        <Play className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

export default function AutomationPage() {
  return (
    <Suspense fallback={null}>
      <AutomationContent />
    </Suspense>
  )
}
