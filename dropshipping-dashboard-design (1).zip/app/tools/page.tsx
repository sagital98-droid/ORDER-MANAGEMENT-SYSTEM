"use client"
import { HelpCircle, User, Zap, BarChart3, FileText, Download, Upload, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sidebar } from "@/components/sidebar"
import { useState } from "react"
import { PrivacyPolicyModal } from "@/components/privacy-policy-modal"

export default function Tools() {
  const [isPrivacyPolicyOpen, setIsPrivacyPolicyOpen] = useState(false)

  const toolCategories = [
    {
      title: "Data Management",
      items: [
        { name: "Export Orders", description: "Download order data as CSV or Excel", icon: Download },
        { name: "Import Products", description: "Bulk upload products from spreadsheet", icon: Upload },
        { name: "Backup Data", description: "Create complete data backup", icon: FileText },
      ],
    },
    {
      title: "Analytics & Reporting",
      items: [
        { name: "Sales Analytics", description: "View detailed sales reports and trends", icon: BarChart3 },
        { name: "Performance Metrics", description: "Track KPIs and business metrics", icon: Zap },
        { name: "Custom Reports", description: "Generate custom business reports", icon: FileText },
      ],
    },
    {
      title: "Settings & Configuration",
      items: [
        { name: "Account Settings", description: "Manage account preferences", icon: Settings },
        { name: "API Keys", description: "Manage integration API keys", icon: Zap },
        { name: "Notifications", description: "Configure alert preferences", icon: HelpCircle },
      ],
    },
  ]

  return (
    <div className="flex h-screen bg-white">
      <Sidebar onPrivacyPolicyClick={() => setIsPrivacyPolicyOpen(true)} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-gray-900">Tools</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <HelpCircle className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <User className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-8 space-y-8">
            {/* Title */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Tools & Utilities</h2>
              <p className="text-gray-600 mt-2">Manage your business data, generate reports, and configure settings</p>
            </div>

            {/* Tool Categories */}
            <div className="space-y-8">
              {toolCategories.map((category, categoryIndex) => (
                <div key={categoryIndex} className="space-y-4">
                  <h3 className="text-xl font-semibold text-gray-900">{category.title}</h3>
                  <div className="grid grid-cols-3 gap-6">
                    {category.items.map((tool, toolIndex) => {
                      const Icon = tool.icon
                      return (
                        <div
                          key={toolIndex}
                          className="bg-gray-50 rounded-lg p-6 border border-gray-200 hover:border-blue-300 hover:shadow-md transition cursor-pointer"
                        >
                          <div className="flex items-start gap-4">
                            <div className="bg-blue-100 p-3 rounded-lg">
                              <Icon className="w-6 h-6 text-blue-600" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900">{tool.name}</h4>
                              <p className="text-sm text-gray-600 mt-1">{tool.description}</p>
                            </div>
                          </div>
                          <div className="mt-4">
                            <Button variant="outline" className="w-full text-sm bg-transparent">
                              Access
                            </Button>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <PrivacyPolicyModal isOpen={isPrivacyPolicyOpen} onClose={() => setIsPrivacyPolicyOpen(false)} />
    </div>
  )
}
