"use client"

import { useState } from "react"
import { HelpCircle, User, Plus, Trash2, Upload, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sidebar } from "@/components/sidebar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"

export default function NewOrderPage() {
  const [orderItems, setOrderItems] = useState([{ id: 1, product: "", quantity: 1, price: 0 }])
  const [nextItemId, setNextItemId] = useState(2)
  const [discount, setDiscount] = useState(0)
  const [sendNotification, setSendNotification] = useState(false)

  const addItem = () => {
    setOrderItems([...orderItems, { id: nextItemId, product: "", quantity: 1, price: 0 }])
    setNextItemId(nextItemId + 1)
  }

  const removeItem = (id: number) => {
    setOrderItems(orderItems.filter((item) => item.id !== id))
  }

  const updateItem = (id: number, field: string, value: any) => {
    setOrderItems(orderItems.map((item) => (item.id === id ? { ...item, [field]: value } : item)))
  }

  const subtotal = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = 0
  const tax = subtotal * 0.1
  const grandTotal = subtotal + shipping + tax - discount

  return (
    <div className="flex h-screen bg-white">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-gray-900">New Order</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <HelpCircle className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <User className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-8 space-y-6 max-w-5xl">
            <h2 className="text-3xl font-bold text-gray-900">Create New Order</h2>

            {/* Form Section */}
            <div className="grid grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                {/* Customer */}
                <Card className="border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-base">Customer</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Input placeholder="" className="w-full border-gray-300" />
                  </CardContent>
                </Card>

                {/* Address */}
                <Card className="border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-base">Shipping Address</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea placeholder="" rows={4} className="w-full border-gray-300" />
                  </CardContent>
                </Card>

                {/* Order Details */}
                <Card className="border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-base">Order Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Shipping Method</label>
                      <select className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option value="">Select shipping method</option>
                        <option>Standard - 5-7 days</option>
                        <option>Express - 2-3 days</option>
                        <option>Overnight</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
                      <select className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option value="">Select payment method</option>
                        <option>Credit Card</option>
                        <option>PayPal</option>
                        <option>Bank Transfer</option>
                        <option>Cash</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Order Date</label>
                      <Input type="date" className="w-full border-gray-300" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Order Status</label>
                      <select className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <option>Pending</option>
                        <option>Paid</option>
                        <option>Shipped</option>
                        <option>Cancelled</option>
                      </select>
                    </div>
                  </CardContent>
                </Card>

                {/* Notes */}
                <Card className="border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-base">Notes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea placeholder="" rows={4} className="w-full border-gray-300" />
                  </CardContent>
                </Card>

                {/* Attachments */}
                <Card className="border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-base">Attachments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <button className="flex items-center justify-center w-full border-2 border-dashed border-gray-300 rounded-md py-8 hover:border-blue-500 transition">
                      <div className="text-center">
                        <Upload className="w-6 h-6 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">Click to upload</p>
                      </div>
                    </button>
                  </CardContent>
                </Card>

                {/* Notification */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="notify"
                    checked={sendNotification}
                    onChange={(e) => setSendNotification(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <label htmlFor="notify" className="text-sm text-gray-700">
                    Send confirmation to customer
                  </label>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                {/* Order Items */}
                <Card className="border border-gray-200">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-base">Order Items</CardTitle>
                    <Button size="sm" onClick={addItem} className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
                      <Plus className="w-4 h-4" />
                      Add Item
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {orderItems.map((item) => (
                      <div key={item.id} className="space-y-2 pb-4 border-b border-gray-100 last:border-0">
                        <Input
                          placeholder=""
                          value={item.product}
                          onChange={(e) => updateItem(item.id, "product", e.target.value)}
                          className="w-full border-gray-300 text-sm"
                        />
                        <div className="grid grid-cols-3 gap-2">
                          <Input
                            type="number"
                            placeholder="Qty"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateItem(item.id, "quantity", Number.parseInt(e.target.value) || 1)}
                            className="border-gray-300 text-sm"
                          />
                          <Input
                            type="number"
                            placeholder="Price"
                            step="0.01"
                            value={item.price}
                            onChange={(e) => updateItem(item.id, "price", Number.parseFloat(e.target.value) || 0)}
                            className="border-gray-300 text-sm"
                          />
                          <Button size="sm" variant="outline" onClick={() => removeItem(item.id)} className="gap-1">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Discount */}
                <Card className="border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-base">Discount</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder=""
                        step="0.01"
                        value={discount}
                        onChange={(e) => setDiscount(Number.parseFloat(e.target.value) || 0)}
                        className="flex-1 border-gray-300"
                      />
                      <Button variant="outline" className="gap-2 bg-transparent">
                        <Plus className="w-4 h-4" />
                        Apply
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Order Summary */}
                <Card className="border border-gray-200 bg-gray-50">
                  <CardHeader>
                    <CardTitle className="text-base">Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="font-medium">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Shipping</span>
                      <span className="font-medium">${shipping.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Tax (10%)</span>
                      <span className="font-medium">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Discount</span>
                      <span className="font-medium">-${discount.toFixed(2)}</span>
                    </div>
                    <div className="border-t border-gray-200 pt-3 flex justify-between">
                      <span className="font-semibold text-gray-900">Grand Total</span>
                      <span className="font-bold text-lg text-blue-600">${grandTotal.toFixed(2)}</span>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex gap-2">
                  <Link href="/orders" className="flex-1">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2">
                      <Check className="w-4 h-4" />
                      Submit
                    </Button>
                  </Link>
                  <Button variant="outline" className="flex-1 hover:bg-gray-100 bg-transparent">
                    Preview Order
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 hover:bg-gray-100 bg-transparent">
                    Save as Draft
                  </Button>
                  <Link href="/orders" className="flex-1">
                    <Button variant="outline" className="w-full hover:bg-gray-100 bg-transparent">
                      Cancel
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
