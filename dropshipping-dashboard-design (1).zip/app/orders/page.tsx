"use client"

import { useState, Suspense } from "react"
import {
  Search,
  Filter,
  Download,
  Upload,
  RefreshCw,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Plus,
  Bell,
} from "lucide-react"
import { HelpCircle, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sidebar } from "@/components/sidebar"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"

function OrdersContent() {
  const [activeTab, setActiveTab] = useState("all")
  const [selectedOrders, setSelectedOrders] = useState(new Set())
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)

  const mockOrders: any[] = []

  const statusColors: Record<string, string> = {
    Paid: "bg-green-100 text-green-800",
    Pending: "bg-orange-100 text-orange-800",
    Shipped: "bg-blue-100 text-blue-800",
    Cancelled: "bg-red-100 text-red-800",
  }

  const filteredOrders = mockOrders.filter((order) => {
    const matchesSearch =
      order.customer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesTab = activeTab === "all" || (activeTab === "unfulfilled" && order.status !== "Shipped")
    return matchesSearch && matchesTab
  })

  const ordersPerPage = 5
  const totalPages = Math.ceil(filteredOrders.length / ordersPerPage) || 1
  const paginatedOrders = filteredOrders.slice((currentPage - 1) * ordersPerPage, currentPage * ordersPerPage)

  const toggleSelectAll = () => {
    if (selectedOrders.size === paginatedOrders.length) {
      setSelectedOrders(new Set())
    } else {
      setSelectedOrders(new Set(paginatedOrders.map((o, i) => i)))
    }
  }

  return (
    <div className="flex h-screen bg-white">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-gray-900">Orders</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <HelpCircle className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <User className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-8 space-y-6">
            {/* Title and Search Bar */}
            <div className="space-y-4">
              <h2 className="text-3xl font-bold text-gray-900">Orders</h2>
              <div className="flex gap-4 items-center">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search orders"
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value)
                      setCurrentPage(1)
                    }}
                    className="pl-10 border-gray-300"
                  />
                </div>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Filter className="w-4 h-4" />
                  Filter
                </Button>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Download className="w-4 h-4" />
                  Export
                </Button>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Upload className="w-4 h-4" />
                  Import
                </Button>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <RefreshCw className="w-4 h-4" />
                  Refresh
                </Button>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <BarChart3 className="w-4 h-4" />
                  Analytics
                </Button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-6 border-b border-gray-200">
              <button
                onClick={() => setActiveTab("all")}
                className={`pb-3 font-medium transition ${
                  activeTab === "all" ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab("unfulfilled")}
                className={`pb-3 font-medium transition ${
                  activeTab === "unfulfilled"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Unfulfilled
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 items-center">
              <Link href="/orders/new">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
                  <Plus className="w-4 h-4" />
                  New Order
                </Button>
              </Link>
              <Button variant="outline" className="gap-2 bg-transparent">
                Drafts
              </Button>
              <Button variant="outline" className="gap-2 bg-transparent">
                Bulk actions
              </Button>
              <Button variant="outline" className="gap-2 bg-transparent">
                More actions
              </Button>
            </div>

            {/* Summary Bar */}
            <div className="grid grid-cols-4 gap-4 bg-gray-50 p-4 rounded-lg">
              <div>
                <div className="text-sm text-gray-600">Total Orders</div>
                <div className="text-2xl font-bold text-gray-900">0</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">In Progress</div>
                <div className="text-2xl font-bold text-gray-900">0</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Completed</div>
                <div className="text-2xl font-bold text-gray-900">0</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Total Revenue</div>
                <div className="text-2xl font-bold text-gray-900">$0.00</div>
              </div>
            </div>

            {/* Orders Table */}
            <Card className="border border-gray-200">
              <CardContent className="p-0">
                {filteredOrders.length === 0 ? (
                  <div className="p-12 text-center">
                    <p className="text-gray-500 text-lg">No orders yet</p>
                    <p className="text-gray-400 text-sm mt-2">Orders will appear here once you start receiving them</p>
                    <Link href="/orders/new">
                      <Button className="mt-4 bg-blue-600 hover:bg-blue-700">Create Your First Order</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200 bg-gray-50">
                          <th className="px-6 py-4 text-left">
                            <input
                              type="checkbox"
                              checked={selectedOrders.size === paginatedOrders.length && paginatedOrders.length > 0}
                              onChange={toggleSelectAll}
                              className="rounded border-gray-300"
                            />
                          </th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Order</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Date</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Customer</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Total</th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paginatedOrders.map((order, index) => (
                          <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition">
                            <td className="px-6 py-4">
                              <input
                                type="checkbox"
                                checked={selectedOrders.has(index)}
                                onChange={() => {
                                  const newSet = new Set(selectedOrders)
                                  if (newSet.has(index)) newSet.delete(index)
                                  else newSet.add(index)
                                  setSelectedOrders(newSet)
                                }}
                                className="rounded border-gray-300"
                              />
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-gray-900">{order.id}</td>
                            <td className="px-6 py-4 text-sm text-gray-600">{order.date}</td>
                            <td className="px-6 py-4 text-sm text-gray-900">{order.customer}</td>
                            <td className="px-6 py-4">
                              <span
                                className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[order.status]}`}
                              >
                                {order.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-gray-900">{order.total}</td>
                            <td className="px-6 py-4">
                              {order.status !== "Paid" && (
                                <Bell className="w-4 h-4 text-orange-500" title="Action required" />
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Pagination */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Showing {(currentPage - 1) * ordersPerPage + 1} to{" "}
                {Math.min(currentPage * ordersPerPage, filteredOrders.length)} of {filteredOrders.length} orders
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="gap-2"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="gap-2"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function OrdersPage() {
  return (
    <Suspense fallback={null}>
      <OrdersContent />
    </Suspense>
  )
}
