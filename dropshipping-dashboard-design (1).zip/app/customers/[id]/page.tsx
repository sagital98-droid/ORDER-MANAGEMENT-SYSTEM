'use client'

import { useState } from 'react'
import { ArrowLeft, Mail, Phone, MapPin, FileText, Plus, Download, Eye, AlertCircle, Lock } from 'lucide-react'
import { Sidebar } from '@/components/sidebar'
import Link from 'next/link'

export default function CustomerDetailsPage({ params }) {
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false)
  const [activeNote, setActiveNote] = useState('')

  // Sample customer data
  const customer = {
    id: params.id,
    name: 'Sarah Mitchell',
    email: 'sarah@example.com',
    phone: '+1 (555) 234-5678',
    status: 'Active',
    loyaltyPoints: 2450,
    totalOrders: 12,
    lifetimeValue: '$3,890.00',
    registrationDate: 'November 22, 2023',
    shippingAddress: '123 Oak Street, Portland, OR 97201',
    billingAddress: '123 Oak Street, Portland, OR 97201',
    customerId: 'CUST-2023-001456',
    tags: ['VIP', 'Regular'],
  }

  const recentOrders = [
    { id: 'ORD-001234', date: '2024-02-15', status: 'Delivered', total: '$450.00', payment: 'Credit Card' },
    { id: 'ORD-001233', date: '2024-02-08', status: 'Shipped', total: '$320.50', payment: 'PayPal' },
    { id: 'ORD-001232', date: '2024-01-28', status: 'Processing', total: '$580.00', payment: 'Credit Card' },
    { id: 'ORD-001231', date: '2024-01-15', status: 'Delivered', total: '$275.75', payment: 'Credit Card' },
    { id: 'ORD-001230', date: '2024-01-02', status: 'Delivered', total: '$890.00', payment: 'PayPal' },
  ]

  const notes = [
    { id: 1, text: 'VIP customer - High value', date: '2024-02-10', pinned: true },
    { id: 2, text: 'Prefers overnight shipping', date: '2024-02-05', pinned: false },
    { id: 3, text: 'Follow up on new product launch', date: '2024-01-28', pinned: false },
  ]

  const activities = [
    { type: 'order', icon: '📦', label: 'Order placed', time: '2 hours ago' },
    { type: 'login', icon: '🔓', label: 'Account login', time: '5 hours ago' },
    { type: 'email', icon: '✉️', label: 'Email sent - Order confirmation', time: '2 days ago' },
    { type: 'order', icon: '📦', label: 'Order placed', time: '1 week ago' },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar onPrivacyPolicyClick={() => setShowPrivacyPolicy(true)} />
      
      <main className="flex-1 p-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <Link href="/customers">
              <button className="text-gray-600 hover:text-gray-900 transition">
                <ArrowLeft className="w-6 h-6" />
              </button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Customer Details</h1>
          </div>
          <div className="flex gap-3">
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export PDF/CSV
            </button>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
              Edit Customer
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Main Content - Left & Center */}
          <div className="col-span-2 space-y-6">
            {/* Customer Info Card */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{customer.name}</h2>
                <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                  customer.status === 'Active' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {customer.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Email</p>
                    <p className="text-sm text-gray-900 font-medium">{customer.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Phone</p>
                    <p className="text-sm text-gray-900 font-medium">{customer.phone}</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Addresses
                </h3>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2">Shipping Address</p>
                    <p className="text-sm text-gray-700">{customer.shippingAddress}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2">Billing Address</p>
                    <p className="text-sm text-gray-700">{customer.billingAddress}</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6 mt-6">
                <div className="grid grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Customer ID</p>
                    <p className="text-sm font-semibold text-gray-900">{customer.customerId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Registration Date</p>
                    <p className="text-sm font-semibold text-gray-900">{customer.registrationDate}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Total Orders</p>
                    <p className="text-sm font-semibold text-gray-900">{customer.totalOrders}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Loyalty Points</p>
                    <p className="text-sm font-semibold text-gray-900">{customer.loyaltyPoints}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <button className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center justify-center gap-2">
                <Mail className="w-4 h-4" />
                Send Email
              </button>
              <button className="flex-1 bg-gray-200 text-gray-900 px-4 py-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center gap-2">
                <FileText className="w-4 h-4" />
                Add Note
              </button>
              <button className="flex-1 bg-gray-200 text-gray-900 px-4 py-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Block Customer
              </button>
              <button className="flex-1 bg-gray-200 text-gray-900 px-4 py-2 rounded-lg hover:bg-gray-300 transition flex items-center justify-center gap-2">
                <Lock className="w-4 h-4" />
                Reset Password
              </button>
            </div>

            {/* Tags */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-3">Customer Type</h3>
              <div className="flex gap-2">
                {customer.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-900">Recent Orders</h3>
                <Link href={`/customers/${params.id}/orders`}>
                  <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                    View All Orders
                  </button>
                </Link>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Order ID</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Date</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Total</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Payment</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order) => (
                      <tr key={order.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="px-4 py-3 font-medium text-gray-900">{order.id}</td>
                        <td className="px-4 py-3 text-gray-600">{order.date}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${
                            order.status === 'Delivered' ? 'bg-green-100 text-green-800' :
                            order.status === 'Shipped' ? 'bg-blue-100 text-blue-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-medium text-gray-900">{order.total}</td>
                        <td className="px-4 py-3 text-gray-600">{order.payment}</td>
                        <td className="px-4 py-3">
                          <Link href={`/customers/${params.id}/orders/${order.id}`}>
                            <button className="text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              View
                            </button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Customer Activity Timeline */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Activity Timeline</h3>
              <div className="space-y-4">
                {activities.map((activity, idx) => (
                  <div key={idx} className="flex gap-4 pb-4 border-b border-gray-200 last:border-0">
                    <span className="text-xl">{activity.icon}</span>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900 font-medium">{activity.label}</p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Right */}
          <div className="space-y-6">
            {/* Key Metrics */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Quick Stats</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-gray-500 uppercase">Lifetime Value</p>
                  <p className="text-2xl font-bold text-gray-900">{customer.lifetimeValue}</p>
                </div>
                <div className="border-t border-gray-200 pt-4">
                  <p className="text-xs text-gray-500 uppercase">Loyalty Points</p>
                  <p className="text-2xl font-bold text-gray-900">{customer.loyaltyPoints}</p>
                </div>
                <div className="border-t border-gray-200 pt-4">
                  <p className="text-xs text-gray-500 uppercase">Total Orders</p>
                  <p className="text-2xl font-bold text-gray-900">{customer.totalOrders}</p>
                </div>
              </div>
            </div>

            {/* Notes Section */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-900">Internal Notes</h3>
                <button className="text-blue-600 hover:text-blue-800">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {notes.map((note) => (
                  <div key={note.id} className={`p-3 rounded-lg border ${
                    note.pinned 
                      ? 'bg-yellow-50 border-yellow-200' 
                      : 'bg-gray-50 border-gray-200'
                  }`}>
                    <p className="text-sm text-gray-900">{note.text}</p>
                    <p className="text-xs text-gray-500 mt-1">{note.date}</p>
                  </div>
                ))}
              </div>
              <button className="w-full mt-4 px-3 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition text-sm font-medium flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" />
                Add New Note
              </button>
            </div>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="mt-8 flex justify-between">
          <Link href="/customers">
            <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
              Back to Customers
            </button>
          </Link>
          <div className="flex gap-3">
            <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
              Save Changes
            </button>
            <button className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition">
              Delete Customer
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
