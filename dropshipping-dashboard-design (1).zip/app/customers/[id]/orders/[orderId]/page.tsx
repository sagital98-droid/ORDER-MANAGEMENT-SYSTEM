'use client'

import { useState } from 'react'
import { ArrowLeft, Download, Printer, RotateCcw, Undo2, MessageSquare, Plus, XCircle } from 'lucide-react'
import { Sidebar } from '@/components/sidebar'
import Link from 'next/link'

export default function OrderDetailsPage({ params }) {
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false)

  // Sample order data
  const order = {
    id: 'ORD-001234',
    date: 'February 15, 2024',
    status: 'Delivered',
    paymentMethod: 'Credit Card',
    transactionId: 'TXN-2024-001234',
    shippingMethod: 'Express Shipping',
    trackingNumber: 'TR-1234567890',
    subtotal: '$450.00',
    tax: '$36.00',
    shipping: '$15.00',
    discount: '-$10.00',
    total: '$491.00',
  }

  const customer = {
    name: 'Sarah Mitchell',
    email: 'sarah@example.com',
    phone: '+1 (555) 234-5678',
    shippingAddress: '123 Oak Street, Portland, OR 97201',
    billingAddress: '123 Oak Street, Portland, OR 97201',
  }

  const products = [
    { id: 1, name: 'Wireless Headphones', sku: 'SKU-001', quantity: 2, unitPrice: '$120.00', total: '$240.00', image: '🎧' },
    { id: 2, name: 'USB-C Charger', sku: 'SKU-002', quantity: 1, unitPrice: '$45.00', total: '$45.00', image: '🔌' },
    { id: 3, name: 'Phone Screen Protector', sku: 'SKU-003', quantity: 3, unitPrice: '$5.00', total: '$15.00', image: '📱' },
  ]

  const timeline = [
    { step: 'Order Placed', status: 'completed', date: 'Feb 15, 2024' },
    { step: 'Processing', status: 'completed', date: 'Feb 15, 2024' },
    { step: 'Shipped', status: 'completed', date: 'Feb 16, 2024' },
    { step: 'Delivered', status: 'completed', date: 'Feb 18, 2024' },
  ]

  const notes = [
    { id: 1, text: 'Customer requested overnight shipping', date: 'Feb 15, 2024', pinned: true },
    { id: 2, text: 'Payment approved without issues', date: 'Feb 15, 2024', pinned: false },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar onPrivacyPolicyClick={() => setShowPrivacyPolicy(true)} />
      
      <main className="flex-1 p-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <Link href={`/customers/${params.id}`}>
              <button className="text-gray-600 hover:text-gray-900 transition">
                <ArrowLeft className="w-6 h-6" />
              </button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Order Details</h1>
          </div>
          <div className="flex gap-3">
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export Invoice (PDF)
            </button>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
              Edit Order
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="col-span-2 space-y-6">
            {/* Order Info Card */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{order.id}</h2>
                  <p className="text-sm text-gray-600 mt-1">{order.date}</p>
                </div>
                <span className="px-4 py-2 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                  {order.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Payment Method</p>
                  <p className="text-sm font-medium text-gray-900">{order.paymentMethod}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Transaction ID</p>
                  <p className="text-sm font-medium text-gray-900">{order.transactionId}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Shipping Method</p>
                  <p className="text-sm font-medium text-gray-900">{order.shippingMethod}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Tracking Number</p>
                  <p className="text-sm font-medium text-gray-900">{order.trackingNumber}</p>
                </div>
              </div>
              <button className="mt-6 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-200 transition font-medium">
                Track Package
              </button>
            </div>

            {/* Order Timeline */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-6">Order Timeline</h3>
              <div className="space-y-4">
                {timeline.map((item, idx) => (
                  <div key={idx} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full ${item.status === 'completed' ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                      {idx < timeline.length - 1 && <div className="w-0.5 h-12 bg-gray-300 my-1"></div>}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{item.step}</p>
                      <p className="text-sm text-gray-600">{item.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Customer Summary */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Customer Summary</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Customer Name</p>
                  <p className="text-sm font-medium text-gray-900">{customer.name}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase mb-2">Email</p>
                  <p className="text-sm font-medium text-gray-900">{customer.email}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-gray-500 uppercase mb-2">Phone</p>
                  <p className="text-sm font-medium text-gray-900">{customer.phone}</p>
                </div>
              </div>

              <div className="border-t border-gray-200 mt-6 pt-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2">Shipping Address</p>
                    <p className="text-sm text-gray-700">{customer.shippingAddress}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2">Billing Address</p>
                    <p className="text-sm text-gray-700">{customer.billingAddress}</p>
                  </div>
                </div>
              </div>

              <Link href={`/customers/${params.id}`}>
                <button className="w-full mt-6 px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition font-medium">
                  View Full Customer Profile
                </button>
              </Link>
            </div>

            {/* Products Section */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Products</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Product</th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">SKU</th>
                      <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Qty</th>
                      <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600">Unit Price</th>
                      <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id} className="border-b border-gray-200">
                        <td className="px-4 py-3 font-medium text-gray-900 flex items-center gap-2">
                          <span className="text-2xl">{product.image}</span>
                          {product.name}
                        </td>
                        <td className="px-4 py-3 text-gray-600">{product.sku}</td>
                        <td className="px-4 py-3 text-center text-gray-900">{product.quantity}</td>
                        <td className="px-4 py-3 text-right text-gray-900">{product.unitPrice}</td>
                        <td className="px-4 py-3 text-right font-medium text-gray-900">{product.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 flex justify-end">
                <div className="w-64 space-y-2 border-t border-gray-200 pt-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="font-medium text-gray-900">{order.subtotal}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Tax:</span>
                    <span className="font-medium text-gray-900">{order.tax}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Shipping:</span>
                    <span className="font-medium text-gray-900">{order.shipping}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Discount:</span>
                    <span className="font-medium text-gray-900">{order.discount}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold border-t border-gray-200 pt-2">
                    <span className="text-gray-900">Total:</span>
                    <span className="text-gray-900">{order.total}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Right */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Actions</h3>
              <div className="space-y-2">
                <button className="w-full px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition text-sm font-medium flex items-center justify-center gap-2">
                  <RotateCcw className="w-4 h-4" />
                  Refund Order
                </button>
                <button className="w-full px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition text-sm font-medium flex items-center justify-center gap-2">
                  <Printer className="w-4 h-4" />
                  Resend Invoice
                </button>
                <button className="w-full px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition text-sm font-medium flex items-center justify-center gap-2">
                  <RotateCcw className="w-4 h-4" />
                  Update Tracking
                </button>
                <button className="w-full px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition text-sm font-medium flex items-center justify-center gap-2">
                  <XCircle className="w-4 h-4" />
                  Cancel Order
                </button>
              </div>
            </div>

            {/* Notes Section */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-900">Internal Notes</h3>
                <button className="text-blue-600 hover:text-blue-800">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {notes.map((note) => (
                  <div key={note.id} className={`p-3 rounded-lg border ${
                    note.pinned 
                      ? 'bg-yellow-50 border-yellow-200' 
                      : 'bg-gray-50 border-gray-200'
                  }`}>
                    <p className="text-sm text-gray-900">{note.text}</p>
                    <p className="text-xs text-gray-500 mt-1">{note.date}</p>
                  </div>
                ))}
              </div>
              <button className="w-full mt-4 px-3 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition text-sm font-medium flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" />
                Add New Note
              </button>
            </div>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="mt-8 flex justify-between">
          <Link href={`/customers/${params.id}`}>
            <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
              Back to Customer Details
            </button>
          </Link>
          <div className="flex gap-3">
            <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
              Save Changes
            </button>
            <button className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition">
              Delete Order
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
