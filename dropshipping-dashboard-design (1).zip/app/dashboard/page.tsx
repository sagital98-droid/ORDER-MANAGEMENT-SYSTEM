"use client"
import { useState } from "react"
import { HelpCircle, User, Package, ShoppingCart, CreditCard, TrendingUp, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sidebar } from "@/components/sidebar"
import { StatCard } from "@/components/stat-card"
import { OrderTable } from "@/components/order-table"
import { SalesChart } from "@/components/sales-chart"
import { SupplierAccounts } from "@/components/supplier-accounts"
import { GlobalPrivacyPolicy } from "@/components/global-privacy-policy"
import Link from "next/link"

const salesData: { month: string; revenue: number; goal: number }[] = []

export default function Dashboard() {
  const [isAddProductOpen, setIsAddProductOpen] = useState(false)
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [isDataCleared, setIsDataCleared] = useState(false)

  const handleClearData = () => {
    setIsDataCleared(true)
  }

  const handleRefreshData = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      setIsRefreshing(false)
    }, 2500)
  }

  return (
    <div className="flex h-screen bg-white">
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-gray-900">Dashboard</h1>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <HelpCircle className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <User className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-8 space-y-8">
            {/* Title */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
            </div>

            <div className="grid grid-cols-4 gap-6">
              <StatCard title="Total Revenue" value="" icon={TrendingUp} color="blue" />
              <StatCard title="Active Products" value="" icon={Package} color="green" />
              <StatCard title="Pending Orders" value="" icon={ShoppingCart} color="orange" />
              <StatCard title="Profit Margin" value="" icon={CreditCard} color="purple" />
            </div>

            <div className="flex gap-4">
              <Link href="/products">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Product
                </Button>
              </Link>
              <Link href="/orders/new">
                <Button className="bg-green-600 hover:bg-green-700 text-white px-6">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Order
                </Button>
              </Link>
              <Button
                onClick={handleRefreshData}
                variant="outline"
                className="px-6 bg-transparent"
                disabled={isRefreshing}
              >
                {isRefreshing ? "Refreshing..." : "Refresh Data"}
              </Button>
              <Button
                onClick={handleClearData}
                variant="outline"
                className="px-6 border-red-300 text-red-600 hover:bg-red-50"
                disabled={isDataCleared}
              >
                {isDataCleared ? "Data Cleared" : "Clear Data"}
              </Button>
              <Link href="/privacy-policy" className="ml-auto">
                <Button variant="ghost" className="text-xs text-gray-400 hover:text-gray-600 px-3 h-8">
                  Privacy Policy
                </Button>
              </Link>
              <Link href="/terms-of-service">
                <Button variant="ghost" className="text-xs text-gray-400 hover:text-gray-600 px-3 h-8">
                  Terms of Service
                </Button>
              </Link>
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-3">
              <label htmlFor="categoryDropdown" className="text-sm font-medium text-gray-700">Category:</label>
              <select
                id="categoryDropdown"
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue=""
              >
                {[
                  "All Categories","Electronics","Computers & Accessories","Mobile Phones & Accessories",
                  "Cameras & Photography","Audio & Headphones","Wearable Technology","Smart Home Devices",
                  "TV & Video","Gaming Consoles & Accessories","Software & Apps","Clothing",
                  "Men's Clothing","Women's Clothing","Kids & Baby Clothing","Shoes & Footwear",
                  "Bags & Luggage","Jewelry & Accessories","Watches","Home & Garden","Furniture",
                  "Home Decor","Kitchen & Dining","Bedding & Bath","Lighting","Garden & Outdoor",
                  "Tools & Home Improvement","Cleaning & Organization","Sports & Outdoors",
                  "Exercise & Fitness","Camping & Hiking","Cycling","Water Sports","Team Sports",
                  "Outdoor Recreation","Winter Sports","Toys & Hobbies","Action Figures & Dolls",
                  "Puzzles & Games","Educational Toys","Model Kits & RC","Arts & Crafts Supplies",
                  "Automotive","Car Accessories","Motorcycle Accessories","Tools & Equipment",
                  "Car Electronics","Tires & Wheels","Health & Beauty","Skincare","Haircare",
                  "Makeup & Cosmetics","Fragrances","Personal Care","Vitamins & Supplements",
                  "Medical Supplies & Equipment","Books & Media","Books (All Genres)",
                  "eBooks & Audiobooks","Music & Vinyl","Movies & TV Shows","Magazines & Comics",
                  "Office & School Supplies","Stationery","Office Electronics","Printers & Ink",
                  "School Supplies","Food & Beverages","Snacks & Candy","Coffee & Tea",
                  "Alcoholic Beverages","Health Foods","Cooking Ingredients","Pet Supplies",
                  "Dog Products","Cat Products","Fish & Aquatic Pets","Birds & Small Animals",
                  "Music & Instruments","Guitars & Strings","Keyboards & Pianos",
                  "Drums & Percussion","Recording & DJ Equipment","Travel & Luggage",
                  "Luggage & Backpacks","Travel Accessories","Outdoor Gear","Miscellaneous",
                  "Collectibles & Memorabilia","Gifts & Special Occasions","Seasonal & Holiday Items"
                ].map((cat) => (
                  <option key={cat} value={cat.toLowerCase().replace(/\s+/g, "_")}>{cat}</option>
                ))}
              </select>
            </div>

            {/* Sales Chart */}
            <SalesChart data={salesData} />

            {/* Bottom Section - Two Columns */}
            <div className="grid grid-cols-2 gap-6">
              <OrderTable />
              <SupplierAccounts />
            </div>
          </div>
        </div>
      </div>

      <GlobalPrivacyPolicy />
    </div>
  )
}
