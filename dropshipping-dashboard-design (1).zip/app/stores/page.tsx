"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { PrivacyPolicyModal } from "@/components/privacy-policy-modal"
import PlatformSelectionScreen from "@/components/stores/platform-selection"
import ConnectStoreForm from "@/components/stores/connect-store-form"
import StoreConnectedSuccess from "@/components/stores/store-connected-success"
import StoreManagement from "@/components/stores/store-management"

export default function StoresPage() {
  const [currentScreen, setCurrentScreen] = useState("selection")
  const [selectedPlatform, setSelectedPlatform] = useState(null)
  const [connectedStores, setConnectedStores] = useState([])
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false)

  const handlePlatformSelect = (platform) => {
    setSelectedPlatform(platform)
    setCurrentScreen("form")
  }

  const handleStoreConnected = (storeData) => {
    setConnectedStores([...connectedStores, storeData])
    setCurrentScreen("success")
  }

  const handleContinueToDashboard = () => {
    setCurrentScreen("management")
  }

  const handleConnectNewStore = () => {
    setSelectedPlatform(null)
    setCurrentScreen("selection")
  }

  return (
    <div className="flex h-screen bg-white">
      <Sidebar onPrivacyPolicyClick={() => setShowPrivacyPolicy(true)} />

      <div className="flex-1 flex flex-col">
        <Header />

        <main className="flex-1 overflow-auto">
          {currentScreen === "selection" && <PlatformSelectionScreen onSelectPlatform={handlePlatformSelect} />}

          {currentScreen === "form" && selectedPlatform && (
            <ConnectStoreForm
              platform={selectedPlatform}
              onStoreConnected={handleStoreConnected}
              onConnectNewStore={handleConnectNewStore}
            />
          )}

          {currentScreen === "success" && selectedPlatform && (
            <StoreConnectedSuccess platform={selectedPlatform} onContinue={handleContinueToDashboard} />
          )}

          {currentScreen === "management" && (
            <StoreManagement connectedStores={connectedStores} onConnectNewStore={handleConnectNewStore} />
          )}
        </main>
      </div>

      {showPrivacyPolicy && <PrivacyPolicyModal onClose={() => setShowPrivacyPolicy(false)} />}
    </div>
  )
}
