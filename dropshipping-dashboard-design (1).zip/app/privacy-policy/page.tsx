"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Download, Search, Info, Shield, Cookie, Clock, Mail, Lock } from "lucide-react"

const sections = [
  {
    id: "information",
    title: "Information We Collect",
    icon: Info,
    content: [
      "Full name",
      "Email address",
      "Phone number",
      "Payment details (if required)",
      "Order history",
      "Device information (IP address, type, browser)",
      "Supplier information (Amazon, eBay, AliExpress, etc.)",
    ],
  },
  {
    id: "how-we-use",
    title: "How We Use Information",
    icon: Mail,
    content: [
      "Order management and supplier synchronization",
      "Sending updates and alerts",
      "Customer support",
      "Legal compliance and responding to requests",
    ],
  },
  {
    id: "sharing",
    title: "Sharing Information with Third Parties",
    icon: Share,
    content: [
      "Suppliers and platforms (AliExpress, Amazon, CJ Dropshipping, eBay – with authorization)",
      "Payment and security service providers",
      "Law enforcement agencies when legally required",
    ],
  },
  {
    id: "how-we-use-data",
    title: "How We Use Your Information",
    icon: Lock,
    content: [
      "Order processing and integrations",
      "Updates, alerts, and monitoring",
      "Customer support",
      "Service improvements and personalization",
    ],
  },
  {
    id: "rights",
    title: "Your Rights",
    icon: Shield,
    content: ["Request access to your information", "Request correction or deletion", "Object to data processing"],
  },
  {
    id: "cookies",
    title: "Cookies",
    icon: Cookie,
    content: [
      "We use cookies to improve user experience and analyze traffic",
      "You may disable cookies in your browser settings",
    ],
  },
  {
    id: "data-retention",
    title: "Data Retention",
    icon: Clock,
    content: ["We retain information only as long as necessary for operational, legal, or regulatory purposes"],
  },
]

function Share() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="18" cy="5" r="3"></circle>
      <circle cx="6" cy="12" r="3"></circle>
      <circle cx="18" cy="19" r="3"></circle>
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
    </svg>
  )
}

export default function PrivacyPolicy() {
  const [searchTerm, setSearchTerm] = useState("")
  const [darkMode, setDarkMode] = useState(false)
  const [agreed, setAgreed] = useState(false)

  const filteredSections = sections.filter(
    (section) =>
      section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      section.content.some((item) => item.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleDownloadPDF = () => {
    // Create a simple PDF-like download
    const policyText = `Privacy Policy\n\n${sections
      .map((s, i) => `${i + 1}. ${s.title}\n${s.content.map((c) => `• ${c}`).join("\n")}`)
      .join(
        "\n\n",
      )}\n\nContact Us\nIf you have any questions about this Privacy Policy, please contact us at:\nsupport@system.com`

    const blob = new Blob([policyText], { type: "text/plain" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "privacy-policy.txt"
    document.body.appendChild(a)
    a.click()
    window.URL.revokeObjectURL(url)
    document.body.removeChild(a)
  }

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className={`min-h-screen ${darkMode ? "dark" : ""}`}>
      <div className="bg-background text-foreground">
        {/* Header */}
        <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex items-center justify-between px-6 py-4">
            <h1 className="text-2xl font-bold">Privacy Policy</h1>
            <div className="flex items-center gap-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search policy..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Dark</span>
                <Switch checked={darkMode} onCheckedChange={setDarkMode} />
              </div>
            </div>
          </div>
        </header>

        <div className="flex">
          {/* Side Navigation */}
          <aside className="hidden w-64 border-r border-border bg-card lg:block">
            <nav className="sticky top-20 space-y-2 p-4">
              <p className="mb-4 px-2 text-sm font-semibold text-muted-foreground">Sections</p>
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className="w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-muted"
                >
                  {section.title}
                </button>
              ))}
            </nav>
          </aside>

          {/* Main Content */}
          <main className="flex-1 px-6 py-8 lg:px-12">
            <div className="max-w-4xl space-y-12">
              {/* Search Bar Mobile */}
              <div className="md:hidden">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search policy..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4"
                  />
                </div>
              </div>

              {/* Sections */}
              {filteredSections.length > 0 ? (
                filteredSections.map((section, index) => {
                  const Icon = section.icon
                  return (
                    <section key={section.id} id={section.id} className="scroll-mt-20 space-y-4">
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5 text-primary" />
                        <h2 className="text-2xl font-bold">
                          {sections.findIndex((s) => s.id === section.id) + 1}. {section.title}
                        </h2>
                      </div>
                      <ul className="space-y-2 pl-8">
                        {section.content.map((item, i) => (
                          <li key={i} className="flex items-start gap-3">
                            <span className="mt-1.5 h-2 w-2 rounded-full bg-primary flex-shrink-0"></span>
                            <span className="text-foreground/90">{item}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="my-8 border-b border-border"></div>
                    </section>
                  )
                })
              ) : (
                <div className="rounded-lg border border-border bg-muted p-8 text-center">
                  <p className="text-muted-foreground">No sections match your search.</p>
                </div>
              )}

              {/* Contact Section */}
              <section className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-primary" />
                  <h2 className="text-2xl font-bold">8. Contact Us</h2>
                </div>
                <p className="pl-8 text-foreground/90">
                  If you have any questions about this Privacy Policy, please contact us at:
                  <br />
                  <span className="mt-2 inline-block font-semibold">📧 support@system.com</span>
                </p>
              </section>

              {/* Agreement & Download */}
              <div className="space-y-6 rounded-lg border border-border bg-card p-6">
                <div className="flex items-center gap-3">
                  <Checkbox checked={agreed} onCheckedChange={setAgreed} id="agree" />
                  <label htmlFor="agree" className="text-sm font-medium cursor-pointer">
                    I agree to the Privacy Policy
                  </label>
                </div>
                <Button onClick={handleDownloadPDF} variant="outline" className="gap-2 bg-transparent">
                  <Download className="h-4 w-4" />
                  Download PDF
                </Button>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
