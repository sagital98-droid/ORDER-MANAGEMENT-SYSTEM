"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export function SupplierAccounts() {
  return (
    <Card className="border border-gray-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Supplier Accounts</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-gray-50 rounded-lg p-8 text-center min-h-48 flex flex-col items-center justify-center">
          <p className="text-gray-500 text-sm mb-6">No suppliers added yet</p>
          <div className="space-y-2 w-full">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2">
              <Plus className="w-4 h-4" />
              Add Supplier
            </Button>
            <Button variant="outline" className="w-full bg-transparent">
              Manage Suppliers
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
