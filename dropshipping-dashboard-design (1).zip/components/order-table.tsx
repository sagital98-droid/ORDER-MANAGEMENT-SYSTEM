import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function OrderTable() {
  return (
    <Card className="border border-gray-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Order Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <div>
          <div className="grid grid-cols-4 gap-4 pb-4 border-b border-gray-200">
            <div className="text-sm font-semibold text-gray-700">Status</div>
            <div className="text-sm font-semibold text-gray-700">Orders</div>
            <div className="text-sm font-semibold text-gray-700">Profit</div>
            <div className="text-sm font-semibold text-gray-700">Last Update</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
