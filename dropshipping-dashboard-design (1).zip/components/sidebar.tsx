"use client"

import { Home, Package, ShoppingCart, TrendingUp, Wrench, Users, Store, Zap } from "lucide-react"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { usePathname } from "next/navigation"

export function Sidebar() {
  const pathname = usePathname()

  const menuItems = [
    { icon: Home, label: "Dashboard", href: "/dashboard" },
    { icon: Package, label: "Products", href: "/products" },
    { icon: ShoppingCart, label: "Orders", href: "/orders" },
    { icon: Store, label: "Stores", href: "/stores" },
    { icon: Users, label: "Customers", href: "/customers" },
    { icon: Wrench, label: "Tools", href: "/tools" },
    { icon: TrendingUp, label: "Price Monitor", href: "/price-monitor" },
    { icon: Zap, label: "Automation", href: "/automation" },
  ]

  return (
    <div className="w-64 bg-gray-900 text-white flex flex-col">
      {/* Logo */}
      <div className="px-6 py-6 border-b border-gray-800">
        <h1 className="text-xl font-bold">Dropship Hub</h1>
      </div>

      {/* Menu Items */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item, index) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link key={index} href={item.href}>
              <button
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition",
                  isActive ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-800",
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
