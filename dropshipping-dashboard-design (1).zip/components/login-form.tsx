// This file is optional - the login form is integrated directly in app/page.tsx
// but keeping this for reference if you want to extract it later
"use client"

export function LoginForm() {
  return null
}
