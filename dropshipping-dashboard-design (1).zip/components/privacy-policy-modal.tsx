"use client"

import { X } from 'lucide-react'
import { useEffect } from "react"

export function PrivacyPolicyModal({ isOpen, onClose }) {
  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/50 z-40 transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />

      {/* Modal with slide-in animation */}
      <div
        className={`fixed right-0 top-0 bottom-0 w-full max-w-2xl bg-white shadow-2xl z-50 overflow-y-auto transition-all duration-300 ease-out ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header with close button */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Privacy Policy</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition">
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <div className="px-8 py-8 space-y-6 text-gray-700">
          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Introduction</h3>
            <p className="leading-relaxed">
              This Privacy Policy explains how Dropship Hub collects, uses, discloses, and safeguards your information
              when you use our platform. Please read this policy carefully to understand our privacy practices.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Information We Collect</h3>
            <p className="leading-relaxed mb-4">We collect information you provide directly, including:</p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>Account registration information (name, email, company details)</li>
              <li>Payment and billing information</li>
              <li>Product and order data</li>
              <li>Communication preferences and support interactions</li>
              <li>Profile information and preferences</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">How We Use Your Information</h3>
            <p className="leading-relaxed mb-4">We use the information we collect to:</p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>Provide, maintain, and improve our services</li>
              <li>Process transactions and send related information</li>
              <li>Send technical notices and updates</li>
              <li>Respond to your inquiries and support requests</li>
              <li>Send marketing and promotional communications (with your consent)</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Data Security</h3>
            <p className="leading-relaxed">
              We implement appropriate technical and organizational measures to protect your personal information
              against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission
              over the Internet is completely secure, and we cannot guarantee absolute security.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Your Rights</h3>
            <p className="leading-relaxed mb-4">
              Depending on your location, you may have certain rights regarding your personal information, including:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>The right to access your personal information</li>
              <li>The right to correct or update your information</li>
              <li>The right to delete your information</li>
              <li>The right to opt-out of marketing communications</li>
              <li>The right to data portability</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Contact Us</h3>
            <p className="leading-relaxed">
              If you have questions about this Privacy Policy or our privacy practices, please contact us at
              privacy@dropshiphub.com or visit our support center.
            </p>
          </section>

          <section className="bg-gray-50 p-6 rounded-lg border border-gray-200">
            <p className="text-sm text-gray-600">
              Last updated: November 2024. We may update this Privacy Policy from time to time. Your continued use of
              our platform following the posting of revised Privacy Policy means you accept and agree to the changes.
            </p>
          </section>
        </div>
      </div>
    </>
  )
}
