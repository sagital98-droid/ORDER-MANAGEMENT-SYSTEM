"use client"

import { HelpCircle, User } from "lucide-react"

export function Header() {
  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
      {/* Left side - could add breadcrumbs or title here */}
      <div className="flex-1" />

      {/* Right side - Icons */}
      <div className="flex items-center gap-6">
        {/* Help Icon */}
        <button className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-600 hover:text-gray-900" title="Help">
          <HelpCircle className="w-5 h-5" />
        </button>

        {/* User Profile Icon */}
        <button
          className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-600 hover:text-gray-900"
          title="Profile"
        >
          <User className="w-5 h-5" />
        </button>
      </div>
    </header>
  )
}
