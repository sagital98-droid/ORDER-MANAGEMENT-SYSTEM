"use client"

const PLATFORM_CONFIG = {
  shopify: { name: "Shopify", color: "#96be4d" },
  ebay: { name: "eBay", color: "#E53238" },
  amazon: { name: "Amazon", color: "#FF9900" },
  etsy: { name: "Etsy", color: "#F1641E" },
  woocommerce: { name: "WooCommerce", color: "#a4286a" },
  wix: { name: "Wix", color: "#FFED66" },
}

export default function StoreConnectedSuccess({ platform, onContinue }) {
  const config = PLATFORM_CONFIG[platform.id]

  return (
    <div className="p-8 min-h-screen flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-lg p-12 max-w-md w-full">
        {/* Success Icon */}
        <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold text-gray-900 text-center mb-2">Store Connected Successfully!</h1>

        {/* Platform Logo and Info */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <div
            className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold"
            style={{ backgroundColor: config.color }}
          >
            {config.name[0]}
          </div>
          <p className="text-lg text-gray-700">Your store ({config.name}) is now connected.</p>
        </div>

        {/* Settings Section */}
        <div className="mb-8">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">Optional: Initial Settings</h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Default Currency</label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>Select currency</option>
                <option>USD</option>
                <option>EUR</option>
                <option>GBP</option>
              </select>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">Enable automatic order syncing</label>
              <input type="checkbox" className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="space-y-3">
          <button
            onClick={onContinue}
            className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold"
          >
            Continue to Dashboard
          </button>
          <button className="w-full text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition font-medium">
            Read the complete connection guide
          </button>
        </div>
      </div>
    </div>
  )
}
