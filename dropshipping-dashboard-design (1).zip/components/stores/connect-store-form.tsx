"use client"

import { useState } from "react"
import { ArrowLeft } from "lucide-react"

const PLATFORM_CONFIG = {
  shopify: { name: "Shopify", color: "#96be4d", fields: ["Store URL", "API Key", "Password"] },
  ebay: { name: "eBay", color: "#E53238", fields: ["Store URL", "Consumer Key", "Consumer Secret"] },
  amazon: { name: "Amazon", color: "#FF9900", fields: ["Store URL", "Seller ID", "Auth Key"] },
  etsy: { name: "Etsy", color: "#F1641E", fields: ["Store URL", "API Key", "API Secret"] },
  woocommerce: { name: "WooCommerce", color: "#a4286a", fields: ["Store URL", "Consumer Key", "Consumer Secret"] },
  wix: { name: "Wix", color: "#FFED66", fields: ["Store URL", "API Key", "API Secret"] },
}

export default function ConnectStoreForm({ platform, onStoreConnected, onConnectNewStore }) {
  const [formData, setFormData] = useState({
    storeUrl: "",
    key: "",
    secret: "",
  })

  const config = PLATFORM_CONFIG[platform.id]

  const handleSubmit = (e) => {
    e.preventDefault()
    onStoreConnected({
      platform: platform.id,
      platformName: config.name,
      storeName: formData.storeUrl.split(".")[0] || "My Store",
      ...formData,
    })
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onConnectNewStore}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <button
          onClick={onConnectNewStore}
          className="px-4 py-2 border-2 border-gray-300 rounded-lg text-gray-900 hover:bg-gray-50 font-medium"
        >
          + Connect New Store
        </button>
      </div>

      {/* Filters Row */}
      <div className="flex gap-4 mb-8">
        <input type="text" placeholder="Search store…" className="flex-1 px-4 py-2 border border-gray-300 rounded-lg" />
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700">
          <option>Platform</option>
        </select>
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700">
          <option>Status</option>
        </select>
      </div>

      {/* Form Card */}
      <div className="bg-white border border-gray-200 rounded-lg p-8">
        {/* Header with Logo and Steps */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Connect Your {config.name} Store</h1>

            {/* Step Indicator */}
            <div className="flex gap-8">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gray-300 text-white font-semibold flex items-center justify-center">
                  1
                </div>
                <span className="text-gray-600">Platform Selection</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-semibold flex items-center justify-center">
                  2
                </div>
                <span className="text-blue-600 font-medium">Authorization</span>
              </div>
            </div>
          </div>

          {/* Platform Logo */}
          <div
            className="w-20 h-20 rounded-lg flex items-center justify-center text-white font-bold text-2xl"
            style={{ backgroundColor: config.color }}
          >
            {config.name[0]}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Store URL</label>
            <input
              type="text"
              placeholder="https://mystore.shopify.com"
              value={formData.storeUrl}
              onChange={(e) => setFormData({ ...formData, storeUrl: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">{config.fields[1]}</label>
            <input
              type="text"
              placeholder={`Enter your ${config.fields[1].toLowerCase()}`}
              value={formData.key}
              onChange={(e) => setFormData({ ...formData, key: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">{config.fields[2]}</label>
            <input
              type="password"
              placeholder={`Enter your ${config.fields[2].toLowerCase()}`}
              value={formData.secret}
              onChange={(e) => setFormData({ ...formData, secret: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <p className="text-sm text-blue-600 font-medium">How to generate {config.name} API keys?</p>

          {/* Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold"
            >
              Authorize and Continue to {config.name}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
