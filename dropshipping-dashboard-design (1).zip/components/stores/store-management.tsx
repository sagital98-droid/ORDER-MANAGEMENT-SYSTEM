"use client"

import { useState } from "react"
import { Eye, RotateCw, RefreshCw, Settings, Plus } from "lucide-react"

const PLATFORM_CONFIG = {
  shopify: { name: "Shopify", color: "#96be4d" },
  ebay: { name: "eBay", color: "#E53238" },
  amazon: { name: "Amazon", color: "#FF9900" },
  etsy: { name: "Etsy", color: "#F1641E" },
  woocommerce: { name: "WooCommerce", color: "#a4286a" },
  wix: { name: "Wix", color: "#FFED66" },
}

export default function StoreManagement({ connectedStores = [], onConnectNewStore }) {
  const [stores] = useState(
    connectedStores && connectedStores.length > 0
      ? connectedStores
      : [
          {
            storeName: "My Shopify Store",
            platform: "shopify",
            status: "Active",
            productsSynced: 245,
            orders: 1024,
          },
          {
            storeName: "eBay Shop",
            platform: "ebay",
            status: "Active",
            productsSynced: 128,
            orders: 542,
          },
        ],
  )

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Store Management</h1>
        <button
          onClick={onConnectNewStore}
          className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition font-medium"
        >
          <Plus className="w-4 h-4" />
          Connect New Store
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-4 mb-8">
        <input type="text" placeholder="Search store…" className="flex-1 px-4 py-2 border border-gray-300 rounded-lg" />
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700">
          <option>Platform</option>
          {Object.values(PLATFORM_CONFIG).map((p) => (
            <option key={p.name}>{p.name}</option>
          ))}
        </select>
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700">
          <option>Status</option>
          <option>Active</option>
          <option>Paused</option>
          <option>Error</option>
        </select>
        <select className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700">
          <option>Last Sync</option>
          <option>Today</option>
          <option>This Week</option>
          <option>This Month</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Store Name</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Platform</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Products Synced</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Orders</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
            </tr>
          </thead>
          <tbody>
            {stores.map((store, index) => {
              const config = PLATFORM_CONFIG[store.platform]
              return (
                <tr key={index} className="border-b border-gray-200 hover:bg-gray-50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900">{store.storeName}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: config.color }}
                      >
                        {config.name[0]}
                      </div>
                      <span className="text-gray-700">{config.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                      {store.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-700">{(store.productsSynced || 0).toLocaleString()}</td>
                  <td className="px-6 py-4 text-gray-700">{(store.orders || 0).toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-gray-200 rounded transition" title="View Store">
                        <Eye className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-200 rounded transition" title="Sync Now">
                        <RotateCw className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-200 rounded transition" title="Refresh">
                        <RefreshCw className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-200 rounded transition" title="Settings">
                        <Settings className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Bottom Buttons */}
      <div className="flex gap-4 mt-8">
        <button className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold">
          Go to Store
        </button>
        <button className="flex-1 border-2 border-blue-600 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition font-semibold">
          Start Managing Products
        </button>
      </div>
    </div>
  )
}
