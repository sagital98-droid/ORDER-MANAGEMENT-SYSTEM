"use client"

import { ArrowRight, HelpCircle } from "lucide-react"

const PLATFORMS = [
  { id: "shopify", name: "Shopify", color: "#96be4d" },
  { id: "ebay", name: "eBay", color: "#E53238" },
  { id: "amazon", name: "Amazon", color: "#FF9900" },
  { id: "etsy", name: "Etsy", color: "#F1641E" },
  { id: "woocommerce", name: "WooCommerce", color: "#a4286a" },
  { id: "wix", name: "Wix", color: "#FFED66" },
]

export default function PlatformSelectionScreen({ onSelectPlatform }) {
  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Connect Your Store</h1>
        <p className="text-lg text-gray-600">Select a platform to connect your store.</p>
      </div>

      {/* Platform Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {PLATFORMS.map((platform) => (
          <div
            key={platform.id}
            className="bg-white border-2 border-gray-200 rounded-lg p-8 hover:border-gray-400 hover:shadow-lg transition cursor-pointer"
            onClick={() => onSelectPlatform(platform)}
          >
            {/* Platform Logo Placeholder */}
            <div
              className="w-16 h-16 rounded-lg mb-4 flex items-center justify-center text-white font-bold text-xl"
              style={{ backgroundColor: platform.color }}
            >
              {platform.name[0]}
            </div>

            {/* Platform Name */}
            <h3 className="text-xl font-semibold text-gray-900 mb-4">{platform.name}</h3>

            {/* Connect Button */}
            <button
              className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition font-medium"
              onClick={() => onSelectPlatform(platform)}
            >
              Connect Store
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Help Link */}
      <div className="text-center">
        <a href="#" className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium">
          <HelpCircle className="w-4 h-4" />
          Need help? View connection guide
        </a>
      </div>
    </div>
  )
}
