"use client"

import { X } from "lucide-react"
import { useAppContext } from "@/app/providers"

export function GlobalPrivacyPolicy() {
  const { isPrivacyPolicyOpen, setIsPrivacyPolicyOpen } = useAppContext()

  if (!isPrivacyPolicyOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50 z-40" onClick={() => setIsPrivacyPolicyOpen(false)} />

      {/* Privacy Policy Drawer */}
      <div className="fixed right-0 top-0 h-full w-full max-w-2xl bg-white shadow-2xl z-50 overflow-y-auto animate-slide-in">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-8 py-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Privacy Policy – Simple & Transparent</h2>
          <button onClick={() => setIsPrivacyPolicyOpen(false)} className="p-2 hover:bg-gray-100 rounded-lg transition">
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <div className="px-8 py-6 space-y-6">
          <p className="text-gray-700 leading-relaxed">
            Hi there! We know privacy policies can be long and boring, so we've decided to keep ours straightforward and
            easy to read. Since you're using our dropshipping management system, we want you to know exactly how we
            handle your data and the data of your customers.
          </p>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">1. What Information Do We Collect?</h3>
            <div className="space-y-3 text-gray-600 leading-relaxed">
              <p>
                <strong className="text-gray-800">Account Info:</strong> When you sign up, we ask for basics like your
                name, email, and contact details so we can set up your workspace.
              </p>
              <p>
                <strong className="text-gray-800">Order Data:</strong> To make the system work for you, we process the
                order details you import (like shipping addresses and product info). This stays within your account for
                your management purposes only.
              </p>
              <p>
                <strong className="text-gray-800">Usage Data:</strong> We collect some technical bits like your IP
                address and how you interact with the app. This helps us fix bugs and make the system faster for you.
              </p>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">2. How Do We Use Your Data?</h3>
            <p className="text-gray-600 leading-relaxed mb-3">We use your information strictly to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600 leading-relaxed ml-4">
              <li>Provide and improve our order management tools.</li>
              <li>Keep your account secure.</li>
              <li>Send you important updates about your orders or system features.</li>
            </ul>
            <p className="text-gray-700 font-semibold mt-4 bg-blue-50 p-4 rounded-lg border border-blue-200">
              The Golden Rule: We do not sell your data (or your customers' data) to third parties. Period. Your
              business data is yours alone.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">3. Keeping Your Data Safe</h3>
            <p className="text-gray-600 leading-relaxed">
              We take security seriously. We use industry-standard encryption and security protocols to ensure that your
              store's information remains private and protected from unauthorized access.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">4. Third-Party Services</h3>
            <p className="text-gray-600 leading-relaxed">
              To keep things running smoothly, we sometimes use trusted partners (like hosting providers or email
              services). They only get the bare minimum information needed to perform their specific task, and they are
              committed to protecting your privacy just as much as we are.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">5. Your Rights</h3>
            <p className="text-gray-600 leading-relaxed">
              It's your data. At any time, you can ask us to see what information we have, update it, or delete it
              entirely. Just give us a shout, and we'll handle it.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">6. Updates to This Policy</h3>
            <p className="text-gray-600 leading-relaxed">
              If we make any big changes to how we handle data, we'll let you know via email or a notification in the
              dashboard. No surprises here.
            </p>
          </section>

          <section className="bg-gray-50 p-6 rounded-lg border border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Questions?</h3>
            <p className="text-gray-600 leading-relaxed">
              We're always happy to chat. Feel free to reach out to us at:{" "}
              <a href="mailto:privacy@dropshiphub.com" className="text-blue-600 hover:text-blue-800 font-medium">
                privacy@dropshiphub.com
              </a>
            </p>
          </section>
        </div>
      </div>
    </>
  )
}
