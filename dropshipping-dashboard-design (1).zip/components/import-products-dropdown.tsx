"use client"

import { useState } from "react"
import { Download, ChevronDown } from "lucide-react"

const importSources = [
  { label: "AliExpress", icon: "🛒" },
  { label: "eBay", icon: "🏷️" },
  { label: "Amazon", icon: "📦" },
  { label: "Walmart", icon: "🏬" },
]

export function ImportProductsDropdown() {
  const [isOpen, setIsOpen] = useState(false)

  const handleImport = (source: string) => {
    console.log(`[v0] Importing from ${source}`)
    // Handle import logic here
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition"
      >
        <Download className="w-4 h-4" />
        Import Products
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full mt-2 right-0 bg-white border border-border rounded-lg shadow-lg p-2 z-50 min-w-[250px]">
          <div className="px-3 py-2 text-sm font-semibold text-foreground border-b border-border mb-2">
            Select Product Source
          </div>

          {importSources.map((source) => (
            <button
              key={source.label}
              onClick={() => handleImport(source.label)}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-secondary transition text-left text-foreground"
            >
              <span className="text-lg">{source.icon}</span>
              <span className="font-medium text-sm">{source.label}</span>
            </button>
          ))}
        </div>
      )}

      {isOpen && <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />}
    </div>
  )
}
